=== Better Click To Tweet ===
Contributors: BenUNC
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=HDSGWRJYFQQNJ
Tags: click to tweet, twitter, tweet, twitter plugin, Twitter boxes, share, social media, auto post
Requires at least: 3.8
Tested up to: 4.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows you to create beautiful Click To Tweet boxes anywhere in your blog post.

== Description ==

This plugin allows you to easily create tweetable content for your readers. Using a simple shortcode, your selected text is highlighted and made tweetable.


== Installation ==

**To install the plugin manually in WordPress:**

1. Login as Admin on your WordPress blog.
2. Click on the "Plugins" tab in the left menu.
3. Select "Add New."
4. Click on "Upload" at the top of the page.
5. Select the 'better-click-to-tweet.zip' on your computer, and upload. Activate the plugin once it is uploaded.

**To install the plugin manually with FTP:**

1. Unzip the 'better-click-to-tweet.zip' file. Upload that folder to the '/wp-content/plugins/' directory.
2. Login to your WordPress dashboard and activate the plugin through the "Plugins" tab in the left menu.

== Frequently Asked Questions ==


= How Does Click To Tweet Work? =

Click To Tweet is a simple plugin that enables you to create beautiful Click To Tweet boxes in your blog posts. By either using simple code or a one-click in your editor, you can generate a custom tweet-able message for your blog readers.

== Screenshots ==

== Changelog ==

= 0.1 =
* Initial release. 